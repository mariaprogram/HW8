
namespace Asteroids.Facade
{
    internal sealed class Map
    {
        public Map(int sizeMap, Player player)
        {
            //...
        }
    }
}