
using UnityEngine;

namespace Asteroids.Facade
{
    internal sealed class Player
    {
        public Player(string playerName)
        {
            //...
        }
    }
}