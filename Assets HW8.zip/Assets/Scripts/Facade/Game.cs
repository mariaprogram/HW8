

namespace Asteroids.Facade
{
    internal sealed class Game
    {
        public Game(Map map)
        {
            //...
        }
        public void Start()
        {
            //...
        }
    }
}