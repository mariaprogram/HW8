
using UnityEngine;

namespace Asteroids.Singleton
{
    public class ExampleSingleton : MonoBehaviour
    {
        
        void Start()
        {
            Services.Instance.Test();
        }

        
    }
}