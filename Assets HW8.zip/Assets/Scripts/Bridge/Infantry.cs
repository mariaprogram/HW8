
namespace Asteroids.Bridge
{
    public class Infantry : IMove
    {
        public void Move()
        {
            throw new System.NotImplementedException();
        }
    }
}