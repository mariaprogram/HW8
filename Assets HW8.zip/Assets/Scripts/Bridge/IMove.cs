
namespace Asteroids.Bridge
{
    public interface IMove
    {
        void Move();
    }
}