
namespace Asteroids.Bridge
{ 
    public interface IAttack
    { 
       void Attack();
    }
}