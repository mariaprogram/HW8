
namespace Asteroids.Bridge
{
    public class MagicalAttack : IAttack
    {
        public void Attack()
        {
            throw new System.NotImplementedException();
        }
    }
}