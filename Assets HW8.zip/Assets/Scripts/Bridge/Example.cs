
using UnityEngine;

namespace Asteroids.Bridge
{
    internal sealed class Example : MonoBehaviour
    {
        private void Start()
        {
            var _enemy = new Enemy(new MagicalAttack(), new Infantry());
        }

    }
}