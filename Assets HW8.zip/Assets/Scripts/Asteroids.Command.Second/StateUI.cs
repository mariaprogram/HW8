

namespace Asteroids.Command.Second
{
    internal enum StateUI
    {
        None = 0,
        PanelOne = 1,
        PanelTwo = 2,
    }
}

