
using UnityEngine;

namespace Asteroids.Abstrac_Factory
{
    internal sealed class PCInput : IInput
    {
        public string Name => nameof(PCInput);
    }
}