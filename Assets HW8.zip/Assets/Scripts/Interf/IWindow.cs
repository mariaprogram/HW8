

namespace Asteroids.Abstrac_Factory
{
    public interface IWindow
    {
        string Name { get; }
    }
}