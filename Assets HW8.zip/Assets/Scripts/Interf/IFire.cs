
using UnityEngine;

namespace Asteroids.Adapter
{
    public interface IFire
    {
        void Fire(Vector3 position);
    }
}