

namespace Asteroids.Abstrac_Factory
{
    public interface IInput
    {
        string Name { get; }
    }
}