
using UnityEngine;

namespace Asteroids.Adapter
{
    public interface IAttack
    {
        void Attack(Vector3 position);
    }
}