
namespace Asteroids.ServiceLocator
{
    internal interface IService
    {
        void Test();
    }
}