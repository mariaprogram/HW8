
namespace Asteroids.Proxy.ProxyProtection
{
    public interface IWeapon
    {
        void Fire();
    }
}