
using UnityEngine;

namespace Asteroids
{
    internal sealed class Starter : MonoBehaviour
    {
        [SerializeField] private Transform _playerPosition;
       
    }
}