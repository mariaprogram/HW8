
namespace Asteroids.Decorator
{
    public interface IFire
    {
        
        void Fire();
    }
}
