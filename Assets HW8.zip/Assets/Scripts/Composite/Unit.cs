
namespace Asteroids.Composite
{
    internal sealed class Unit : IAttack
    {
        public void Attack()
        {
            throw new System.NotImplementedException();
        }


    }
}