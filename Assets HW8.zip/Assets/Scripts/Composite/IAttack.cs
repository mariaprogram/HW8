
namespace Asteroids.Composite
{
    public interface IAttack
    {
        void Attack();
    }
}