
using UnityEngine;

namespace Asteroids
{
    internal sealed class Asteroid : Enemy
    {
        
    }
}