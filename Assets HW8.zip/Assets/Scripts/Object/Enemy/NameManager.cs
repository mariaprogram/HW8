
namespace Asteroids.Object_Pool
{
    internal static class NameManager
    {
        public const string POOL_AMMUNITION = "[Pool_Ammunition]";

    }
}