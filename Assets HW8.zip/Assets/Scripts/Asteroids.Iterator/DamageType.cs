
namespace Asteroids.Iterator
{
    internal enum DamageType
    {
        None = 0,
        Magical = 1,
        Pure = 2,
    }
}

